import fetch from 'node-fetch';

export default async function handler(req, res) {
  if (req.method === 'GET') {
    try {
      // 1️⃣ API ke liye payload
      const payload = {
        pageSize: 10,
        pageNo: 1,
        typeId: 1,
        language: 0,
        random: "4a0522c6ecd8410496260e686be2a57c",
        signature: "334B5E70A0C9B8918B0B15E517E2069C",
        timestamp: Math.floor(Date.now() / 1000)
      };

      // 2️⃣ API se data fetch
      const response = await fetch("https://api.bdg88zf.com/api/webapi/GetNoaverageEmerdList", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await response.json();

      if (data.code === 0 && data.data.list) {
        const lastResults = data.data.list.slice(0, 7);
        const pattern = detectPattern(lastResults);

        // 3️⃣ Firebase pe pattern save
        await fetch("https://<YOUR_FIREBASE_PROJECT>.firebaseio.com/patterns.json", {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            period: data.data.list[0].issueNumber,
            pattern: pattern,
            numbers: lastResults.map(item => item.number),
            timestamp: Date.now()
          })
        });

        res.status(200).json({ status: "Pattern saved", pattern });
      } else {
        res.status(500).json({ error: 'API response invalid' });
      }

    } catch (error) {
      console.error("🔥 Error:", error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  } else {
    res.status(405).json({ error: 'Method Not Allowed' });
  }
}

// Pattern detect logic
function detectPattern(results) {
  return results.map(item => (item.number > 4 ? 'BIG' : 'SMALL')).join('-');
}